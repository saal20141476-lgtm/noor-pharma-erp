
-- نور فارما ERP: مخطط تأسيسي لقاعدة مشتركة.
-- شغّله في مشروع جديد/بيئة اختبار فقط بعد المراجعة. لا يحذف أو يعدل جداول موجودة.
create extension if not exists pgcrypto;

create table if not exists public.organizations (
  id uuid primary key default gen_random_uuid(),
  name text not null,
  created_at timestamptz not null default now()
);

create table if not exists public.profiles (
  user_id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '',
  created_at timestamptz not null default now()
);

create table if not exists public.organization_members (
  organization_id uuid not null references public.organizations(id) on delete cascade,
  user_id uuid not null references auth.users(id) on delete cascade,
  role text not null check (role in ('system_admin','inventory_manager','accountant','viewer')),
  created_at timestamptz not null default now(),
  primary key (organization_id,user_id)
);

create table if not exists public.items (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  sku text not null,
  name text not null,
  base_unit text not null default 'حبة',
  book_qty numeric(14,3) not null default 0 check (book_qty >= 0),
  min_qty numeric(14,3) not null default 0 check (min_qty >= 0),
  cost numeric(14,4) not null default 0 check (cost >= 0),
  sale_price numeric(14,4) not null default 0 check (sale_price >= 0),
  active boolean not null default true,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now(),
  unique (organization_id, sku)
);

create table if not exists public.item_barcodes (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  item_id uuid not null references public.items(id) on delete cascade,
  barcode text not null,
  unit_name text not null default 'حبة',
  unit_factor numeric(14,3) not null default 1 check (unit_factor > 0),
  is_primary boolean not null default false,
  created_at timestamptz not null default now(),
  unique (organization_id, barcode)
);

create table if not exists public.count_sessions (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  code text not null,
  count_date date not null default current_date,
  status text not null default 'draft' check (status in ('draft','closed','approved','cancelled')),
  created_by uuid references auth.users(id),
  approved_by uuid references auth.users(id),
  created_at timestamptz not null default now(),
  closed_at timestamptz,
  approved_at timestamptz,
  unique (organization_id, code)
);

create table if not exists public.count_lines (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  session_id uuid not null references public.count_sessions(id) on delete cascade,
  item_id uuid not null references public.items(id),
  book_qty_snapshot numeric(14,3) not null,
  actual_qty numeric(14,3) check (actual_qty is null or actual_qty >= 0),
  note text not null default '',
  counted_by uuid references auth.users(id),
  counted_at timestamptz,
  unique (session_id,item_id)
);

create table if not exists public.stock_movements (
  id uuid primary key default gen_random_uuid(),
  organization_id uuid not null references public.organizations(id) on delete cascade,
  item_id uuid not null references public.items(id),
  movement_type text not null check (movement_type in ('opening','purchase','sale','return_in','return_out','adjustment','transfer_in','transfer_out')),
  quantity_delta numeric(14,3) not null,
  unit_cost numeric(14,4) not null default 0,
  reference_type text,
  reference_id uuid,
  note text not null default '',
  created_by uuid references auth.users(id),
  created_at timestamptz not null default now()
);

create index if not exists idx_items_org_name on public.items(organization_id, name);
create index if not exists idx_barcodes_org_code on public.item_barcodes(organization_id, barcode);
create index if not exists idx_count_sessions_org_date on public.count_sessions(organization_id, count_date desc);
create index if not exists idx_stock_movements_org_created on public.stock_movements(organization_id, created_at desc);

create or replace function public.is_org_member(org_id uuid)
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.organization_members m where m.organization_id = org_id and m.user_id = auth.uid()); $$;

create or replace function public.has_org_role(org_id uuid, allowed_roles text[])
returns boolean language sql stable security definer set search_path = public
as $$ select exists (select 1 from public.organization_members m where m.organization_id = org_id and m.user_id = auth.uid() and m.role = any(allowed_roles)); $$;

alter table public.organizations enable row level security;
alter table public.profiles enable row level security;
alter table public.organization_members enable row level security;
alter table public.items enable row level security;
alter table public.item_barcodes enable row level security;
alter table public.count_sessions enable row level security;
alter table public.count_lines enable row level security;
alter table public.stock_movements enable row level security;

drop policy if exists "org member reads own org" on public.organizations;
create policy "org member reads own org" on public.organizations for select to authenticated using (public.is_org_member(id));

drop policy if exists "user reads own profile" on public.profiles;
create policy "user reads own profile" on public.profiles for select to authenticated using (user_id = auth.uid());
drop policy if exists "user updates own profile" on public.profiles;
create policy "user updates own profile" on public.profiles for update to authenticated using (user_id = auth.uid()) with check (user_id = auth.uid());

drop policy if exists "members read memberships in their org" on public.organization_members;
create policy "members read memberships in their org" on public.organization_members for select to authenticated using (public.is_org_member(organization_id));

drop policy if exists "members read items" on public.items;
create policy "members read items" on public.items for select to authenticated using (public.is_org_member(organization_id));
drop policy if exists "inventory roles write items" on public.items;
create policy "inventory roles write items" on public.items for all to authenticated using (public.has_org_role(organization_id, array['system_admin','inventory_manager'])) with check (public.has_org_role(organization_id, array['system_admin','inventory_manager']));

drop policy if exists "members read barcodes" on public.item_barcodes;
create policy "members read barcodes" on public.item_barcodes for select to authenticated using (public.is_org_member(organization_id));
drop policy if exists "inventory roles write barcodes" on public.item_barcodes;
create policy "inventory roles write barcodes" on public.item_barcodes for all to authenticated using (public.has_org_role(organization_id, array['system_admin','inventory_manager'])) with check (public.has_org_role(organization_id, array['system_admin','inventory_manager']));

drop policy if exists "members read count sessions" on public.count_sessions;
create policy "members read count sessions" on public.count_sessions for select to authenticated using (public.is_org_member(organization_id));
drop policy if exists "inventory roles manage count sessions" on public.count_sessions;
create policy "inventory roles manage count sessions" on public.count_sessions for all to authenticated using (public.has_org_role(organization_id, array['system_admin','inventory_manager'])) with check (public.has_org_role(organization_id, array['system_admin','inventory_manager']));

drop policy if exists "members read count lines" on public.count_lines;
create policy "members read count lines" on public.count_lines for select to authenticated using (public.is_org_member(organization_id));
drop policy if exists "inventory roles manage count lines" on public.count_lines;
create policy "inventory roles manage count lines" on public.count_lines for all to authenticated using (public.has_org_role(organization_id, array['system_admin','inventory_manager'])) with check (public.has_org_role(organization_id, array['system_admin','inventory_manager']));

drop policy if exists "members read stock movements" on public.stock_movements;
create policy "members read stock movements" on public.stock_movements for select to authenticated using (public.is_org_member(organization_id));
drop policy if exists "admin accountant manage movements" on public.stock_movements;
create policy "admin accountant manage movements" on public.stock_movements for all to authenticated using (public.has_org_role(organization_id, array['system_admin','accountant'])) with check (public.has_org_role(organization_id, array['system_admin','accountant']));

-- ملاحظة: إنشاء المؤسسة وربط أول مستخدم بها يجب أن يتم من لوحة Supabase/مسار إداري آمن.
-- لا توجد سياسة تسجيل ذاتي لإنشاء عضويات؛ تجنب منح المستخدم صلاحية تعيين دوره بنفسه.
