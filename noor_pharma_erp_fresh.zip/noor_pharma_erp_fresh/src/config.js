// ضع بيانات مشروع Supabase هنا. لا تضع service_role key في التطبيق.
export const SUPABASE_URL = "";
export const SUPABASE_ANON_KEY = "";
export const APP_NAME = "نور فارما ERP";
