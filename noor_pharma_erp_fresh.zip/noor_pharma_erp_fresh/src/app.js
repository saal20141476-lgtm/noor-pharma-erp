
import './style.css';
import { SUPABASE_URL, SUPABASE_ANON_KEY, APP_NAME } from './config.js';

const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const STORE_KEY = 'noor_pharma_erp_v1';
let db = loadLocal();
let supabase = null;
let currentPage = 'dashboard';
let activeCount = null;
let cameraScanner = null;

function loadLocal(){
  try { return JSON.parse(localStorage.getItem(STORE_KEY)) || {items:[], counts:[], settings:{}}; }
  catch { return {items:[], counts:[], settings:{}}; }
}
function saveLocal(){ localStorage.setItem(STORE_KEY, JSON.stringify(db)); }
function esc(v=''){return String(v).replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));}
function money(v){return Number(v||0).toLocaleString('ar-SA',{maximumFractionDigits:3});}
function toast(msg){let n=document.createElement('div');n.className='toast';n.textContent=msg;document.body.append(n);setTimeout(()=>n.remove(),2800);}
function pageTitle(){return ({dashboard:'لوحة المؤشرات',items:'الأصناف والمخزون',count:'الجرد المخزني',reports:'التقارير',settings:'الإعدادات'})[currentPage]||APP_NAME;}
function nav(){
  return `<aside class="sidebar" id="sidebar"><div class="brand"><div class="brand-mark">ن</div><div><h1>نور فارما</h1><small>نظام إدارة الصيدلية</small></div></div>
  ${[['dashboard','▦','لوحة المؤشرات'],['items','▤','الأصناف والمخزون'],['count','✓','الجرد المخزني'],['reports','▥','التقارير'],['settings','⚙','الإعدادات']].map(([id,ic,label])=>`<button class="nav-btn ${currentPage===id?'active':''}" data-page="${id}"><span>${ic}</span>${label}</button>`).join('')}
  <div class="side-note">الإصدار التأسيسي 1.0<br>وضع التخزين: ${supabase?'قاعدة مشتركة':'محلي تجريبي'}</div></aside>`;
}
function app(){
 $('#app').innerHTML=`<div class="app-shell">${nav()}<main class="main">
 <header class="topbar"><div style="display:flex;align-items:center;gap:10px"><button class="btn-secondary mobile-menu" id="mobileMenu">☰</button><div><h2>${pageTitle()}</h2><div class="muted">إدارة المخزون والجرد — نور فارما</div></div></div>
 <div class="toolbar"><span class="status">${supabase?'متصل بقاعدة مشتركة':'وضع تجريبي محلي'}</span></div></header>
 <section id="pageContent">${renderPage()}</section></main></div>`;
 bindGlobal();
}
function renderPage(){
 if(currentPage==='dashboard') return dashboard();
 if(currentPage==='items') return itemsPage();
 if(currentPage==='count') return countPage();
 if(currentPage==='reports') return reportsPage();
 return settingsPage();
}
function dashboard(){
 const active=db.items.filter(x=>x.active!==false);
 const qty=active.reduce((s,x)=>s+Number(x.bookQty||0),0);
 const low=active.filter(x=>Number(x.bookQty||0)<=Number(x.minQty||0)).length;
 const latest=db.counts.at(-1);
 return `<div class="grid">
 <div class="card"><div class="kpi-label">إجمالي الأصناف</div><div class="kpi-value">${money(active.length)}</div><div class="muted">صنف مسجل</div></div>
 <div class="card"><div class="kpi-label">إجمالي الكميات الدفترية</div><div class="kpi-value">${money(qty)}</div><div class="muted">بوحدات الأصناف</div></div>
 <div class="card"><div class="kpi-label">أصناف عند حد الطلب</div><div class="kpi-value">${money(low)}</div><div class="muted">تحتاج مراجعة</div></div>
 <div class="card"><div class="kpi-label">جلسات الجرد</div><div class="kpi-value">${money(db.counts.length)}</div><div class="muted">${latest?`آخر جلسة: ${esc(latest.date)}`:'لا توجد جلسات بعد'}</div></div>
 </div>
 <div class="panel"><div class="section-head"><h3>ابدأ بسرعة</h3></div><div class="toolbar">
 <button class="btn-primary" data-page="items">＋ إضافة صنف</button><button class="btn-secondary" data-page="count">بدء جرد جديد</button><button class="btn-secondary" data-page="reports">عرض التقارير</button>
 </div><p class="muted" style="margin-top:18px;line-height:2">نصيحة رقابية: احتفظ بنسخة احتياطية قبل الاستيراد أو تعديل أرصدة المخزون. لا تعتمد فروقات الجرد محاسبيًا قبل المراجعة والموافقة.</p></div>
 <div class="panel" style="margin-top:16px"><div class="section-head"><h3>آخر الأصناف المضافة</h3><button class="btn-secondary" data-page="items">عرض الكل</button></div>${itemTable(active.slice(-5).reverse())}</div>`;
}
function itemTable(list){
 if(!list.length)return `<div class="empty">لا توجد أصناف بعد. أضف صنفًا أو استورد ملفًا.</div>`;
 return `<div class="table-wrap"><table><thead><tr><th>الكود</th><th>اسم الصنف</th><th>الباركود</th><th>الوحدة</th><th>الرصيد الدفتري</th><th>حد الطلب</th><th>الحالة</th><th class="no-print">إجراء</th></tr></thead><tbody>${list.map(x=>`<tr><td>${esc(x.sku||'—')}</td><td><b>${esc(x.name)}</b></td><td>${esc(x.barcode||'—')}</td><td>${esc(x.unit||'حبة')}</td><td>${money(x.bookQty)}</td><td>${money(x.minQty)}</td><td>${Number(x.bookQty||0)<=Number(x.minQty||0)?'<span class="tag warn">مراجعة</span>':'<span class="tag">متوفر</span>'}</td><td class="no-print"><button class="btn-secondary" data-edit="${esc(x.id)}">تعديل</button> <button class="btn-danger" data-delete="${esc(x.id)}">حذف</button></td></tr>`).join('')}</tbody></table></div>`;
}
function itemsPage(){
 return `<div class="panel"><div class="section-head"><h3>دليل الأصناف</h3><div class="toolbar"><button class="btn-primary" id="addItem">＋ إضافة صنف</button><button class="btn-secondary" id="importBtn">استيراد Excel / CSV</button><button class="btn-secondary" id="exportBtn">تصدير CSV</button><input type="file" id="importFile" accept=".csv,.xlsx,.xls" hidden></div></div>
 <div class="toolbar" style="margin-bottom:14px"><input class="search" id="itemSearch" placeholder="ابحث بالاسم أو الكود أو الباركود..."></div>
 <div id="itemsTable">${itemTable(db.items.filter(x=>x.active!==false).slice().reverse())}</div>
 <p class="muted">أعمدة الاستيراد المقترحة: sku, name, barcode, unit, bookQty, minQty, cost, price. يقبل التطبيق كذلك عناوين عربية مثل: الكود، اسم الصنف، الباركود، الوحدة، الرصيد، حد الطلب، التكلفة، سعر البيع.</p></div>
 <div id="itemModal"></div>`;
}
function countPage(){
 const counts=db.counts.slice().reverse();
 return `<div class="panel"><div class="section-head"><h3>جلسات الجرد</h3><div class="toolbar"><button class="btn-primary" id="newCount">＋ بدء جرد جديد</button><button class="btn-secondary" id="scanOpen">▦ قراءة باركود</button></div></div>
 ${activeCount?countEditor(activeCount):`<div class="muted" style="margin-bottom:12px">اختر جلسة للمتابعة أو أنشئ جلسة جديدة. كل جلسة تحفظ الكميات الفعلية والفروقات للمراجعة.</div>`}
 ${counts.length?`<div class="table-wrap" style="margin-top:16px"><table><thead><tr><th>رقم الجلسة</th><th>التاريخ</th><th>الحالة</th><th>عدد البنود</th><th>إجراء</th></tr></thead><tbody>${counts.map(c=>`<tr><td>${esc(c.code)}</td><td>${esc(c.date)}</td><td>${c.status==='approved'?'<span class="tag">معتمد</span>':c.status==='closed'?'<span class="tag warn">مغلق للمراجعة</span>':'<span class="tag warn">مسودة</span>'}</td><td>${money(c.lines.length)}</td><td><button class="btn-secondary" data-open-count="${esc(c.id)}">فتح</button> <button class="btn-secondary" data-count-report="${esc(c.id)}">تقرير</button></td></tr>`).join('')}</tbody></table></div>`:`<div class="empty">لا توجد جلسات جرد. اضغط «بدء جرد جديد».</div>`}
 <div id="scannerArea"></div></div>`;
}
function countEditor(c){
 const lines=c.lines.map(l=>{const it=db.items.find(x=>x.id===l.itemId)||{};return {...l,itemName:it.name||l.itemName||'صنف محذوف',sku:it.sku||l.sku||''};});
 return `<div style="background:#f6faf9;border-radius:12px;padding:14px"><div class="section-head"><div><b>${esc(c.code)}</b><div class="muted">تاريخ الجرد: ${esc(c.date)} — ${c.status==='approved'?'معتمد':c.status==='closed'?'مغلق':'مسودة'}</div></div><div class="toolbar"><button class="btn-secondary" id="addCountLine">＋ إضافة بند</button><button class="btn-secondary" id="scanCount">▦ مسح باركود</button><button class="btn-primary" id="saveCount">حفظ</button><button class="btn-secondary" id="closeCount">إغلاق للمراجعة</button><button class="btn-secondary" id="printCount">طباعة التقرير</button></div></div>
 <div class="toolbar" style="margin:10px 0"><input class="search" id="countSearch" placeholder="ابحث عن صنف لإضافته..." /><span class="muted">لا يتم تعديل الرصيد الدفتري تلقائيًا عند الجرد.</span></div>
 <div id="countSearchResults"></div>
 <div class="table-wrap"><table><thead><tr><th>الكود</th><th>الصنف</th><th>الدفترية</th><th>الفعلية</th><th>الفرق</th><th>ملاحظات</th><th>إجراء</th></tr></thead><tbody>${lines.map(l=>`<tr><td>${esc(l.sku)}</td><td>${esc(l.itemName)}</td><td>${money(l.bookQty)}</td><td><input style="width:100px" type="number" min="0" step="any" data-actual="${esc(l.itemId)}" value="${l.actualQty===null||l.actualQty===undefined?'':esc(l.actualQty)}" ${c.status!=='draft'?'disabled':''}></td><td><b>${l.actualQty===null||l.actualQty===undefined?'—':money(Number(l.actualQty)-Number(l.bookQty))}</b></td><td><input data-note="${esc(l.itemId)}" value="${esc(l.note||'')}" placeholder="ملاحظة" ${c.status!=='draft'?'disabled':''}></td><td><button class="btn-danger" data-remove-line="${esc(l.itemId)}" ${c.status!=='draft'?'disabled':''}>حذف</button></td></tr>`).join('')}</tbody></table></div></div>`;
}
function reportsPage(){
 const last=db.counts.at(-1);
 const rows=db.counts.flatMap(c=>c.lines.filter(l=>l.actualQty!==null&&l.actualQty!==undefined).map(l=>({c,l,it:db.items.find(x=>x.id===l.itemId)||{}})));
 const diff=rows.reduce((s,r)=>s+Number(r.l.actualQty)-Number(r.l.bookQty),0);
 return `<div class="grid"><div class="card"><div class="kpi-label">إجمالي بنود الجرد المكتملة</div><div class="kpi-value">${money(rows.length)}</div></div><div class="card"><div class="kpi-label">صافي فرق الكمية</div><div class="kpi-value">${money(diff)}</div></div><div class="card"><div class="kpi-label">جلسات غير معتمدة</div><div class="kpi-value">${money(db.counts.filter(c=>c.status!=='approved').length)}</div></div><div class="card"><div class="kpi-label">آخر جرد</div><div class="kpi-value" style="font-size:18px">${last?esc(last.date):'—'}</div></div></div>
 <div class="panel"><div class="section-head"><h3>تقرير فروقات الجرد</h3><div class="toolbar"><select id="reportSession"><option value="all">كل الجلسات</option>${db.counts.slice().reverse().map(c=>`<option value="${esc(c.id)}">${esc(c.code)} — ${esc(c.date)}</option>`).join('')}</select><button class="btn-primary" id="printReport">طباعة / PDF</button><button class="btn-secondary" id="exportReport">تصدير CSV</button></div></div><div id="reportTable">${reportTable(rows)}</div><p class="muted">الفرق = الكمية الفعلية − الكمية الدفترية. التقرير يعرض فروقات الكمية فقط ولا يُعد قيدًا محاسبيًا أو اعتمادًا لتسوية المخزون.</p></div>`;
}
function reportTable(rows){
 if(!rows.length)return `<div class="empty">لا توجد كميات فعلية مسجلة في الجرد حتى الآن.</div>`;
 return `<div class="table-wrap"><table><thead><tr><th>الجلسة</th><th>التاريخ</th><th>الكود</th><th>اسم الصنف</th><th>الدفترية</th><th>الفعلية</th><th>الفرق</th><th>الملاحظة</th></tr></thead><tbody>${rows.map(({c,l,it})=>{let d=Number(l.actualQty)-Number(l.bookQty);return `<tr><td>${esc(c.code)}</td><td>${esc(c.date)}</td><td>${esc(it.sku||l.sku||'')}</td><td>${esc(it.name||l.itemName||'')}</td><td>${money(l.bookQty)}</td><td>${money(l.actualQty)}</td><td><span class="tag ${d<0?'bad':d>0?'warn':''}">${d>0?'+':''}${money(d)}</span></td><td>${esc(l.note||'—')}</td></tr>`}).join('')}</tbody></table></div>`;
}
function settingsPage(){
 return `<div class="panel"><div class="section-head"><h3>إعدادات قاعدة البيانات المشتركة</h3></div><p class="muted" style="line-height:2">اربط المشروع بقاعدة Supabase لتفعيل تسجيل الدخول والمزامنة. هذه الواجهة لا ترسل أي بيانات إلى قاعدة سحابية ما لم تدخل بيانات الربط وتُفعّل الجداول والسياسات.</p>
 <div class="form-grid"><div class="field full"><label>Supabase Project URL</label><input id="sbUrl" placeholder="https://xxxxxxxx.supabase.co" value="${esc(localStorage.getItem('noor_sb_url')||SUPABASE_URL)}"></div><div class="field full"><label>Anon / Publishable Key</label><textarea id="sbKey" rows="3" placeholder="مفتاح anon أو publishable فقط">${esc(localStorage.getItem('noor_sb_key')||SUPABASE_ANON_KEY)}</textarea></div></div>
 <div class="actions"><button class="btn-primary" id="connectSb">حفظ الإعدادات والاتصال</button><button class="btn-secondary" id="disconnectSb">استخدام الوضع المحلي</button></div>
 <hr style="border:0;border-top:1px solid #e4ecee;margin:24px 0"><h3>نسخ احتياطي محلي</h3><p class="muted">ينشئ نسخة JSON من بيانات هذا الجهاز فقط. لا تعتبر بديلًا عن النسخ الاحتياطي لقاعدة البيانات المشتركة.</p><div class="actions"><button class="btn-secondary" id="backupBtn">تنزيل نسخة JSON</button><button class="btn-secondary" id="restoreBtn">استعادة نسخة JSON</button><input type="file" id="restoreFile" accept=".json" hidden></div>
 <div style="margin-top:24px;background:#fff8e8;border:1px solid #f2dfb1;border-radius:12px;padding:14px;font-size:13px;line-height:1.9"><b>تنبيه أمني:</b> لا تضع مفتاح <code>service_role</code> هنا أو داخل التطبيق. لا تفعّل صلاحيات عامة على جداول المخزون. راجع RLS وربط كل مستخدم بالمؤسسة قبل تشغيل بيانات فعلية.</div></div>`;
}
function bindGlobal(){
 $$('[data-page]').forEach(b=>b.onclick=()=>{currentPage=b.dataset.page;activeCount=null;app();});
 $('#mobileMenu')?.addEventListener('click',()=>$('#sidebar')?.classList.toggle('open'));
 $('#addItem')?.addEventListener('click',()=>showItemModal());
 $('#itemSearch')?.addEventListener('input',e=>{let q=e.target.value.toLowerCase();$('#itemsTable').innerHTML=itemTable(db.items.filter(x=>x.active!==false&&[x.name,x.sku,x.barcode].some(v=>String(v||'').toLowerCase().includes(q))).slice().reverse());bindItemActions();});
 bindItemActions();
 $('#importBtn')?.addEventListener('click',()=>$('#importFile').click());
 $('#importFile')?.addEventListener('change',importFile);
 $('#exportBtn')?.addEventListener('click',exportItems);
 $('#newCount')?.addEventListener('click',newCount);
 $$('[data-open-count]').forEach(b=>b.onclick=()=>{activeCount=db.counts.find(c=>c.id===b.dataset.openCount);app();});
 $$('[data-count-report]').forEach(b=>b.onclick=()=>printSingleCount(b.dataset.countReport));
 $('#addCountLine')?.addEventListener('click',()=>$('#countSearch')?.focus());
 $('#countSearch')?.addEventListener('input',e=>showCountSearch(e.target.value));
 $('#saveCount')?.addEventListener('click',saveCountLines);
 $('#closeCount')?.addEventListener('click',closeCount);
 $('#printCount')?.addEventListener('click',()=>printSingleCount(activeCount?.id));
 $('#scanOpen')?.addEventListener('click',()=>startScanner('scannerArea',code=>{currentPage='items';app();$('#itemSearch').value=code;$('#itemSearch').dispatchEvent(new Event('input'));}));
 $('#scanCount')?.addEventListener('click',()=>startScanner('scannerArea',code=>{stopScanner();$('#countSearch').value=code;showCountSearch(code);}));
 $$('[data-actual]').forEach(i=>i.addEventListener('change',()=>{let l=activeCount?.lines.find(x=>x.itemId===i.dataset.actual);if(l)l.actualQty=i.value===''?null:Number(i.value);}));
 $$('[data-note]').forEach(i=>i.addEventListener('change',()=>{let l=activeCount?.lines.find(x=>x.itemId===i.dataset.note);if(l)l.note=i.value;}));
 $$('[data-remove-line]').forEach(b=>b.onclick=()=>{if(activeCount?.status!=='draft')return;activeCount.lines=activeCount.lines.filter(x=>x.itemId!==b.dataset.removeLine);saveLocal();app();});
 $('#printReport')?.addEventListener('click',()=>window.print());
 $('#reportSession')?.addEventListener('change',e=>{let ids=e.target.value;let rows=db.counts.filter(c=>ids==='all'||c.id===ids).flatMap(c=>c.lines.filter(l=>l.actualQty!==null&&l.actualQty!==undefined).map(l=>({c,l,it:db.items.find(x=>x.id===l.itemId)||{}})));$('#reportTable').innerHTML=reportTable(rows);});
 $('#exportReport')?.addEventListener('click',exportReport);
 $('#connectSb')?.addEventListener('click',connectSupabase);
 $('#disconnectSb')?.addEventListener('click',()=>{supabase=null;localStorage.removeItem('noor_sb_url');localStorage.removeItem('noor_sb_key');toast('تم اختيار الوضع المحلي');app();});
 $('#backupBtn')?.addEventListener('click',backup);
 $('#restoreBtn')?.addEventListener('click',()=>$('#restoreFile').click());
 $('#restoreFile')?.addEventListener('change',restore);
}
function bindItemActions(){
 $$('[data-edit]').forEach(b=>b.onclick=()=>showItemModal(db.items.find(x=>x.id===b.dataset.edit)));
 $$('[data-delete]').forEach(b=>b.onclick=()=>{if(confirm('هل تريد حذف الصنف؟ ستبقى بياناته التاريخية في جلسات الجرد.')){let x=db.items.find(x=>x.id===b.dataset.delete);if(x)x.active=false;saveLocal();app();toast('تم إخفاء الصنف من الدليل');}});
}
function showItemModal(item=null){
 const isEdit=!!item;
 $('#itemModal').innerHTML=`<div style="position:fixed;inset:0;background:#0b2028a8;z-index:30;display:grid;place-items:center;padding:14px"><form id="itemForm" class="panel" style="width:min(620px,100%);max-height:92vh;overflow:auto"><div class="section-head"><h3>${isEdit?'تعديل صنف':'إضافة صنف جديد'}</h3><button type="button" class="btn-secondary" id="cancelItem">إغلاق</button></div><div class="form-grid">
 <div class="field"><label>كود الصنف (SKU)</label><input name="sku" value="${esc(item?.sku||'')}" required></div>
 <div class="field"><label>اسم الصنف</label><input name="name" value="${esc(item?.name||'')}" required></div>
 <div class="field"><label>الباركود</label><input name="barcode" value="${esc(item?.barcode||'')}"></div>
 <div class="field"><label>الوحدة الأساسية</label><input name="unit" value="${esc(item?.unit||'حبة')}"></div>
 <div class="field"><label>الرصيد الدفتري</label><input name="bookQty" type="number" min="0" step="any" value="${esc(item?.bookQty??0)}" required></div>
 <div class="field"><label>حد الطلب</label><input name="minQty" type="number" min="0" step="any" value="${esc(item?.minQty??0)}"></div>
 <div class="field"><label>التكلفة</label><input name="cost" type="number" min="0" step="any" value="${esc(item?.cost??0)}"></div>
 <div class="field"><label>سعر البيع</label><input name="price" type="number" min="0" step="any" value="${esc(item?.price??0)}"></div></div>
 <div class="actions"><button class="btn-primary" type="submit">حفظ الصنف</button></div></form></div>`;
 $('#cancelItem').onclick=()=>$('#itemModal').innerHTML='';
 $('#itemForm').onsubmit=e=>{e.preventDefault();let f=new FormData(e.target);let obj={id:item?.id||crypto.randomUUID(),sku:String(f.get('sku')).trim(),name:String(f.get('name')).trim(),barcode:String(f.get('barcode')).trim(),unit:String(f.get('unit')).trim()||'حبة',bookQty:Number(f.get('bookQty')||0),minQty:Number(f.get('minQty')||0),cost:Number(f.get('cost')||0),price:Number(f.get('price')||0),active:true,updatedAt:new Date().toISOString()};if(item)db.items=db.items.map(x=>x.id===item.id?obj:x);else db.items.push(obj);saveLocal();$('#itemModal').innerHTML='';app();toast('تم حفظ الصنف محليًا');};
}
function newCount(){
 const c={id:crypto.randomUUID(),code:'CNT-'+new Date().toISOString().slice(0,10).replaceAll('-','')+'-'+String(db.counts.length+1).padStart(3,'0'),date:new Date().toISOString().slice(0,10),status:'draft',lines:db.items.filter(x=>x.active!==false).map(x=>({itemId:x.id,itemName:x.name,sku:x.sku,bookQty:Number(x.bookQty||0),actualQty:null,note:''})),createdAt:new Date().toISOString()};
 db.counts.push(c);activeCount=c;saveLocal();app();toast('تم إنشاء جلسة جرد؛ راجع البنود والكميات');
}
function showCountSearch(q){
 const target=$('#countSearchResults');if(!target||!activeCount)return;
 q=String(q||'').trim().toLowerCase();if(!q){target.innerHTML='';return;}
 const list=db.items.filter(x=>x.active!==false&&[x.name,x.sku,x.barcode].some(v=>String(v||'').toLowerCase().includes(q))).slice(0,8);
 target.innerHTML=list.length?`<div class="card" style="margin:10px 0">${list.map(x=>`<div style="display:flex;justify-content:space-between;gap:8px;align-items:center;padding:8px;border-bottom:1px solid #edf1f2"><div><b>${esc(x.name)}</b><div class="muted">${esc(x.sku)} · ${esc(x.barcode||'بدون باركود')}</div></div><button class="btn-primary" data-add-line="${esc(x.id)}">إضافة</button></div>`).join('')}</div>`:`<div class="muted" style="padding:10px">لا توجد نتائج</div>`;
 $$('[data-add-line]',target).forEach(b=>b.onclick=()=>{let x=db.items.find(i=>i.id===b.dataset.addLine);if(x&&!activeCount.lines.some(l=>l.itemId===x.id))activeCount.lines.push({itemId:x.id,itemName:x.name,sku:x.sku,bookQty:Number(x.bookQty||0),actualQty:null,note:''});saveLocal();app();});
}
function saveCountLines(){
 if(!activeCount)return;
 $$('[data-actual]').forEach(i=>{let l=activeCount.lines.find(x=>x.itemId===i.dataset.actual);if(l)l.actualQty=i.value===''?null:Number(i.value);});
 $$('[data-note]').forEach(i=>{let l=activeCount.lines.find(x=>x.itemId===i.dataset.note);if(l)l.note=i.value;});
 saveLocal();toast('تم حفظ الجرد على هذا الجهاز');app();
}
function closeCount(){
 if(!activeCount)return;
 saveCountLines();
 if(activeCount.lines.some(l=>l.actualQty===null||l.actualQty===undefined)){toast('أكمل الكميات الفعلية قبل إغلاق الجلسة');return;}
 activeCount.status='closed';saveLocal();app();toast('أغلقت الجلسة للمراجعة، ولم تُعدّل الأرصدة الدفترية');
}
function csvCell(v){return '"'+String(v??'').replaceAll('"','""')+'"';}
function download(name,content,type='text/csv;charset=utf-8;'){
 const blob=new Blob(['\ufeff',content],{type});const a=document.createElement('a');a.href=URL.createObjectURL(blob);a.download=name;a.click();setTimeout(()=>URL.revokeObjectURL(a.href),1000);
}
function exportItems(){let cols=['sku','name','barcode','unit','bookQty','minQty','cost','price'];download('noor-pharma-items.csv',[cols.join(','),...db.items.map(x=>cols.map(k=>csvCell(x[k])).join(','))].join('\r\n')); }
function exportReport(){let rows=db.counts.flatMap(c=>c.lines.filter(l=>l.actualQty!==null&&l.actualQty!==undefined).map(l=>{let it=db.items.find(x=>x.id===l.itemId)||{};return [c.code,c.date,it.sku||l.sku,it.name||l.itemName,l.bookQty,l.actualQty,Number(l.actualQty)-Number(l.bookQty),l.note]}));download('noor-pharma-count-variance.csv',[['session','date','sku','name','bookQty','actualQty','variance','note'].join(','),...rows.map(r=>r.map(csvCell).join(','))].join('\r\n'));}
function importFile(e){
 const file=e.target.files?.[0];if(!file)return;
 const readText=async()=>{const txt=await file.text();const lines=txt.replace(/^\uFEFF/,'').split(/\r?\n/).filter(x=>x.trim());if(!lines.length)return;const delim=(lines[0].match(/;/g)||[]).length>(lines[0].match(/,/g)||[]).length?';':',';const parse=line=>{let out=[],cur='',q=false;for(let i=0;i<line.length;i++){let c=line[i];if(c==='"'&&line[i+1]==='"'){cur+='"';i++;}else if(c==='"')q=!q;else if(c===delim&&!q){out.push(cur.trim());cur='';}else cur+=c;}out.push(cur.trim());return out;};const headers=parse(lines[0]).map(h=>mapHeader(h));let n=0;for(const line of lines.slice(1)){const vals=parse(line);const row={};headers.forEach((h,i)=>row[h]=vals[i]??'');if(!row.name)continue;upsertImported(row);n++;}saveLocal();app();toast(`تم استيراد ${n} صنفًا إلى الوضع المحلي`);};
 if(/\.(xlsx|xls)$/i.test(file.name)){
  import('https://cdn.jsdelivr.net/npm/xlsx@0.18.5/+esm').then(XLSX=>{const reader=new FileReader();reader.onload=ev=>{const wb=XLSX.read(ev.target.result,{type:'array'});const rows=XLSX.utils.sheet_to_json(wb.Sheets[wb.SheetNames[0]],{defval:''});let n=0;rows.forEach(r=>{let row={};Object.entries(r).forEach(([k,v])=>row[mapHeader(k)]=v);if(row.name){upsertImported(row);n++;}});saveLocal();app();toast(`تم استيراد ${n} صنفًا محليًا`);};reader.readAsArrayBuffer(file);}).catch(()=>toast('تعذر تحميل قارئ Excel. جرّب CSV أو تحقق من الاتصال.'));
 }else readText().catch(()=>toast('تعذر قراءة الملف'));
 e.target.value='';
}
function mapHeader(h){const x=String(h||'').trim().toLowerCase().replace(/\s+/g,'');const map={sku:'sku',code:'sku',itemcode:'sku','الكود':'sku','كودالصنف':'sku',name:'name',item:'name','اسم الصنف':'name','اسمالصنف':'name','الصنف':'name',barcode:'barcode','باركود':'barcode','الباركود':'barcode',unit:'unit','الوحدة':'unit',bookqty:'bookQty',qty:'bookQty',quantity:'bookQty','الرصيد':'bookQty','الكمية':'bookQty','الرصيدالدفترى':'bookQty','الرصيدالدفترية':'bookQty',minqty:'minQty','حدالطلب':'minQty',cost:'cost','التكلفة':'cost',price:'price','سعرالبيع':'price'};return map[x]||map[String(h||'').trim()]||x;}
function upsertImported(r){
 const sku=String(r.sku||'').trim();const barcode=String(r.barcode||'').trim();let found=db.items.find(x=>(sku&&x.sku===sku)||(barcode&&x.barcode===barcode));
 const obj={id:found?.id||crypto.randomUUID(),sku,name:String(r.name||found?.name||'').trim(),barcode,unit:String(r.unit||found?.unit||'حبة'),bookQty:Number(r.bookQty??found?.bookQty??0)||0,minQty:Number(r.minQty??found?.minQty??0)||0,cost:Number(r.cost??found?.cost??0)||0,price:Number(r.price??found?.price??0)||0,active:true,updatedAt:new Date().toISOString()};
 if(found)db.items=db.items.map(x=>x.id===found.id?obj:x);else db.items.push(obj);
}
function backup(){download('noor-pharma-backup.json',JSON.stringify({exportedAt:new Date().toISOString(),db},null,2),'application/json');}
function restore(e){const f=e.target.files?.[0];if(!f)return;const r=new FileReader();r.onload=()=>{try{const obj=JSON.parse(r.result);if(!obj.db||!Array.isArray(obj.db.items)||!Array.isArray(obj.db.counts))throw new Error('format');if(confirm(`استعادة ${obj.db.items.length} صنفًا و${obj.db.counts.length} جلسة جرد؟ سيتم استبدال بيانات هذا الجهاز.`)){db=obj.db;saveLocal();app();toast('تمت الاستعادة محليًا');}}catch{toast('ملف النسخة الاحتياطية غير صالح');}};r.readAsText(f);e.target.value='';}
async function connectSupabase(){
 const url=$('#sbUrl').value.trim(),key=$('#sbKey').value.trim();
 if(!url.startsWith('https://')||!key){toast('أدخل Project URL ومفتاح anon/publishable');return;}
 try{
  const {createClient}=await import('https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2/+esm');
  const client=createClient(url,key);
  const {error}=await client.auth.getSession();
  if(error)throw error;
  supabase=client;localStorage.setItem('noor_sb_url',url);localStorage.setItem('noor_sb_key',key);
  toast('تم الاتصال بالخدمة. يلزم استكمال تسجيل الدخول والمزامنة قبل استخدام البيانات المشتركة.');app();
 }catch(err){toast('تعذر الاتصال: تحقق من الرابط والمفتاح والاتصال بالإنترنت');console.error(err);}
}
async function startScanner(targetId,onCode){
 const target=$('#'+targetId);if(!target){toast('مكان قارئ الباركود غير متاح');return;}
 target.innerHTML=`<div class="panel" style="margin-top:14px"><div class="section-head"><h3>قارئ الباركود</h3><button id="stopScan" class="btn-secondary">إيقاف</button></div><div id="reader" style="max-width:500px"></div><div class="muted">اسمح للمتصفح باستخدام الكاميرا عند الطلب.</div></div>`;
 $('#stopScan').onclick=stopScanner;
 try{
  const mod=await import('https://cdn.jsdelivr.net/npm/html5-qrcode@2.3.8/+esm');
  cameraScanner=new mod.Html5Qrcode('reader');
  await cameraScanner.start({facingMode:'environment'},{fps:10,qrbox:{width:250,height:150}},decoded=>{onCode(decoded);stopScanner();},()=>{});
 }catch(err){target.innerHTML=`<div class="panel" style="margin-top:12px"><p>تعذر تشغيل الكاميرا. تحقق من إذن الكاميرا أو أدخل الباركود يدويًا.</p><input id="manualBarcode" placeholder="أدخل الباركود"><button id="manualUse" class="btn-primary">استخدام الباركود</button></div>`;$('#manualUse').onclick=()=>onCode($('#manualBarcode').value.trim());}
}
async function stopScanner(){if(cameraScanner){try{await cameraScanner.stop();cameraScanner.clear();}catch{}cameraScanner=null;}$('#scannerArea')?.replaceChildren();}
function printSingleCount(id){
 const c=db.counts.find(x=>x.id===id);if(!c)return;
 const rows=c.lines.map(l=>{const it=db.items.find(x=>x.id===l.itemId)||{};const d=l.actualQty==null?'':Number(l.actualQty)-Number(l.bookQty);return `<tr><td>${esc(it.sku||l.sku||'')}</td><td>${esc(it.name||l.itemName||'')}</td><td>${money(l.bookQty)}</td><td>${l.actualQty==null?'—':money(l.actualQty)}</td><td>${d===''?'—':money(d)}</td><td>${esc(l.note||'')}</td></tr>`}).join('');
 const w=window.open('','_blank');if(!w){toast('اسمح بالنوافذ المنبثقة لطباعة التقرير');return;}
 w.document.write(`<html lang="ar" dir="rtl"><head><meta charset="utf-8"><title>تقرير جرد ${esc(c.code)}</title><style>body{font-family:Arial,sans-serif;padding:24px;color:#172b35}h1{font-size:22px}p{color:#52676f}table{width:100%;border-collapse:collapse;margin-top:18px}th,td{border:1px solid #ccd7da;padding:8px;text-align:right;font-size:12px}th{background:#eef4f4}@media print{button{display:none}}</style></head><body><h1>نور فارما — تقرير جرد مخزني</h1><p>رقم الجلسة: ${esc(c.code)} | التاريخ: ${esc(c.date)} | الحالة: ${esc(c.status)}</p><table><thead><tr><th>الكود</th><th>الصنف</th><th>الدفترية</th><th>الفعلية</th><th>الفرق</th><th>ملاحظات</th></tr></thead><tbody>${rows}</tbody></table><p>الفرق = الفعلية − الدفترية. هذا التقرير للمراجعة ولا يمثل اعتماد تسوية مخزون.</p><button onclick="window.print()">طباعة / حفظ PDF</button></body></html>`);w.document.close();
}
function renderInitial(){app();}
renderInitial();
