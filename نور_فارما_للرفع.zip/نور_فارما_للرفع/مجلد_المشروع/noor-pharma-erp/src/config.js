// Noor Pharma ERP — Supabase public client configuration.
// Never put sb_secret or service_role keys in this client-side file.
export const SUPABASE_URL = "https://ktkahoxwzhxfjuycqegy.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "sb_publishable_Kgs2pNxi8O9uQZi5xo2j_Q_jalW6HI0";
