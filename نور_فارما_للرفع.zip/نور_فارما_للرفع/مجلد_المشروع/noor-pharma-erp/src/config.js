// إعداد اتصال نور فارما بمشروع Supabase الذي يحتوي حسابات المستخدمين الحالية.
// مفتاح anon من نوع public client key، ولا تستخدم أبدًا sb_secret أو service_role داخل التطبيق.
export const SUPABASE_URL = "https://wzbathmgjqvaoblihelp.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6Ind6YmF0aG1nanF2YW9ibGloZWxwIiwicm9sZSI6ImFub24iLCJpYXQiOjE3OTIwMDI0MjQsImV4cCI6MjEwNzU3ODQyNH0.-K_LMhVt5v6axZVxRNXwY8p6OzAZUAyJJEHVKquKyfU";
