// ضع رابط مشروع Supabase والمفتاح العام publishable فقط هنا.
// لا تستخدم sb_secret أو service_role داخل تطبيق الهاتف.
export const SUPABASE_URL = "https://ktkahoxwzhxfjuycqegy.supabase.co";
export const SUPABASE_PUBLISHABLE_KEY = "";
