
-- نور فارما ERP - migration additive for project already initialized.
-- This script does not delete data or drop policies. Run once in the new project.
create extension if not exists pgcrypto;
create table if not exists public.stock_movements (
 id uuid primary key default gen_random_uuid(),
 organization_id uuid not null references public.organizations(id) on delete cascade,
 item_id uuid not null references public.items(id),
 movement_type text not null check (movement_type in ('opening','purchase','sale','return_in','return_out','adjustment','transfer_in','transfer_out')),
 quantity_delta numeric(14,3) not null,
 unit_cost numeric(14,4) not null default 0,
 note text not null default '',
 created_by uuid references auth.users(id),
 created_at timestamptz not null default now()
);
alter table public.stock_movements enable row level security;
do $$ begin
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='stock_movements' and policyname='movement read member') then
  create policy "movement read member" on public.stock_movements for select to authenticated using (public.is_org_member(organization_id));
 end if;
 if not exists (select 1 from pg_policies where schemaname='public' and tablename='stock_movements' and policyname='movement write admin accountant') then
  create policy "movement write admin accountant" on public.stock_movements for all to authenticated using (public.has_org_role(organization_id,array['system_admin','accountant'])) with check (public.has_org_role(organization_id,array['system_admin','accountant']));
 end if;
end $$;
