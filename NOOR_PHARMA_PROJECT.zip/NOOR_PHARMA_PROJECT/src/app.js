
import './style.css';
import { createClient } from '@supabase/supabase-js';
import { SUPABASE_URL, SUPABASE_PUBLISHABLE_KEY } from './config.js';

const $=s=>document.querySelector(s);
const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const num=n=>Number(n||0).toLocaleString('ar-SA',{maximumFractionDigits:3});
const client=SUPABASE_PUBLISHABLE_KEY ? createClient(SUPABASE_URL,SUPABASE_PUBLISHABLE_KEY,{auth:{persistSession:true,autoRefreshToken:true,detectSessionInUrl:true}}):null;
let session=null, membership=null, items=[], page='dashboard', loading=false;
let errorMsg='', okMsg='';
function message(t,ok=false){errorMsg=ok?'':t;okMsg=ok?t:'';render();}
function roleLabel(r){return ({system_admin:'مدير النظام',inventory_manager:'مسؤول الجرد',accountant:'المحاسب',viewer:'مشاهد'})[r]||r||'—';}
function canEdit(){return membership && ['system_admin','inventory_manager'].includes(membership.role);}
function escMsg(){return `${errorMsg?`<div class="alert error">${esc(errorMsg)}</div>`:''}${okMsg?`<div class="alert success">${esc(okMsg)}</div>`:''}`;}
function loginView(){return `<div class="authbox"><h1>نور فارما ERP</h1><p class="muted">تسجيل الدخول إلى قاعدة بيانات الصيدلية المشتركة</p>${escMsg()}${!client?`<div class="alert">لم يُضف المفتاح العام بعد. افتح src/config.js وأدخل Supabase Publishable Key فقط.</div>`:''}<form id="login"><div class="field"><label>البريد الإلكتروني</label><input name="email" type="email" required autocomplete="username"></div><div class="field"><label>كلمة المرور</label><input name="password" type="password" required autocomplete="current-password"></div><button class="btn" style="width:100%" ${!client?'disabled':''}>تسجيل الدخول</button></form><p class="muted">أنشئ المستخدم مسبقًا من Supabase Authentication → Users. لا يوجد تسجيل ذاتي مفتوح.</p></div>`;}
function shell(){return `<div class="shell"><aside class="side"><div class="brand">نور فارما</div><button class="nav ${page==='dashboard'?'active':''}" data-page="dashboard">لوحة المؤشرات</button><button class="nav ${page==='items'?'active':''}" data-page="items">الأصناف والمخزون</button><button class="nav ${page==='count'?'active':''}" data-page="count">الجرد المخزني</button><button class="nav ${page==='settings'?'active':''}" data-page="settings">الإعدادات</button></aside><main class="main"><header class="top"><div><h1>${({dashboard:'لوحة المؤشرات',items:'الأصناف والمخزون',count:'الجرد المخزني',settings:'الإعدادات'})[page]}</h1><div class="muted">${esc(session?.user?.email)} · ${esc(roleLabel(membership?.role))}</div></div><div class="row"><span class="tag">قاعدة مشتركة</span><button id="logout" class="alt">تسجيل الخروج</button></div></header>${escMsg()}${content()}</main></div>`;}
function content(){
 if(page==='dashboard')return `<div class="grid"><div class="kpi"><div class="muted">الأصناف</div><div class="value">${num(items.length)}</div></div><div class="kpi"><div class="muted">إجمالي الرصيد الدفتري</div><div class="value">${num(items.reduce((s,i)=>s+Number(i.book_qty||0),0))}</div></div><div class="kpi"><div class="muted">صلاحية المستخدم</div><div class="value" style="font-size:18px">${esc(roleLabel(membership?.role))}</div></div></div><div class="panel"><h3>اتصال قاعدة البيانات</h3><p>تم تحميل بيانات المؤسسة المرتبطة بحسابك من Supabase. التغييرات التي تحفظها هنا تُرسل إلى قاعدة البيانات المشتركة.</p><p class="muted">لا تستخدم هذه النسخة مع بيانات إنتاجية قبل اختبار صلاحيات كل دور وإعداد نسخة احتياطية.</p></div>`;
 if(page==='items')return `<div class="panel"><div class="row" style="justify-content:space-between"><h3>دليل الأصناف</h3><div class="row"><input id="search" placeholder="بحث بالاسم أو الكود..." style="width:220px"><button id="reload" class="alt">تحديث</button>${canEdit()?'<button id="add" class="btn">إضافة صنف</button>':''}</div></div><div id="itemform"></div><div class="tablewrap"><table><thead><tr><th>الكود</th><th>اسم الصنف</th><th>الوحدة</th><th>الرصيد</th><th>حد الطلب</th><th>التكلفة</th><th>سعر البيع</th></tr></thead><tbody id="rows">${itemRows(items)}</tbody></table></div></div>`;
 if(page==='count')return `<div class="panel"><h3>الجرد المخزني</h3><p>تم تجهيز الجداول الأساسية للجرد في قاعدة البيانات. واجهة إنشاء الجلسات واعتماد الفروقات ستُستكمل بعد اختبار المزامنة مع الأصناف.</p><div class="alert">لا يتم تعديل الرصيد الدفتري تلقائيًا بسبب الجرد. يجب حفظ لقطة الرصيد عند بدء الجلسة ثم اعتماد التسوية بمسار منفصل.</div></div>`;
 return `<div class="panel"><h3>معلومات الاتصال</h3><p>عنوان المشروع: ${esc(SUPABASE_URL)}</p><p>المؤسسة: ${esc(membership?.organization_name||'نور فارما')}</p><p>الدور: ${esc(roleLabel(membership?.role))}</p><button id="reload" class="alt">إعادة تحميل البيانات</button></div>`;
}
function itemRows(list){if(!list.length)return '<tr><td colspan="7" class="empty">لا توجد أصناف في المؤسسة بعد.</td></tr>';return list.map(i=>`<tr><td>${esc(i.sku)}</td><td>${esc(i.name)}</td><td>${esc(i.base_unit)}</td><td>${num(i.book_qty)}</td><td>${num(i.min_qty)}</td><td>${num(i.cost)}</td><td>${num(i.sale_price)}</td></tr>`).join('');}
function render(){
 $('#app').innerHTML=session&&membership?shell():loginView();
 $('#login')?.addEventListener('submit',login);
 $('#logout')?.addEventListener('click',logout);
 document.querySelectorAll('[data-page]').forEach(b=>b.onclick=()=>{page=b.dataset.page;render();});
 $('#reload')?.addEventListener('click',loadItems);
 $('#add')?.addEventListener('click',showItemForm);
 $('#search')?.addEventListener('input',e=>{$('#rows').innerHTML=itemRows(items.filter(i=>[i.name,i.sku].some(v=>String(v||'').toLowerCase().includes(e.target.value.toLowerCase()))));});
}
async function login(e){
 e.preventDefault();if(!client)return;
 const fd=new FormData(e.target);
 const {data,error}=await client.auth.signInWithPassword({email:fd.get('email'),password:fd.get('password')});
 if(error){
   const detail=String(error.message||'').toLowerCase();
   let friendly='تعذر تسجيل الدخول. راجع رسالة الخطأ: '+String(error.message||'خطأ غير معروف');
   if(detail.includes('invalid login credentials')) friendly='البريد الإلكتروني أو كلمة المرور غير صحيحة في مشروع الصيدلية الذي يحتوي هذا الحساب.';
   else if(detail.includes('email not confirmed')) friendly='البريد الإلكتروني غير مؤكّد في Supabase. أكّد البريد أو راجع حالة الحساب في Authentication → Users.';
   else if(detail.includes('invalid api key')||detail.includes('invalid jwt')||detail.includes('api key')) friendly='مفتاح الاتصال لا يطابق مشروع Supabase. تحقّق من رابط المشروع والمفتاح العام معًا.';
   else if(detail.includes('failed to fetch')||detail.includes('network')) friendly='تعذّر الاتصال بـ Supabase. تحقّق من الإنترنت ورابط المشروع.';
   message(friendly);return;
 }
 session=data.session;await resolveMembership();
}
async function logout(){if(client)await client.auth.signOut();session=null;membership=null;items=[];render();}
async function resolveMembership(){
 if(!session)return;
 const {data,error}=await client.from('organization_members').select('organization_id,user_id,role,organizations(name)').eq('user_id',session.user.id).limit(1).maybeSingle();
 if(error){membership=null;message('تم تسجيل الدخول لكن تعذر قراءة عضوية المؤسسة. تحقق من سياسات RLS.');return;}
 if(!data){membership=null;message('هذا الحساب غير مرتبط بمؤسسة نور فارما. أضف عضويته من لوحة الإدارة.');return;}
 membership={organization_id:data.organization_id,user_id:data.user_id,role:data.role,organization_name:data.organizations?.name||'نور فارما'};
 errorMsg='';okMsg='تم تسجيل الدخول وربط المؤسسة بنجاح.';await loadItems();
}
async function loadItems(){
 if(!client||!membership)return;
 const {data,error}=await client.from('items').select('id,sku,name,base_unit,book_qty,min_qty,cost,sale_price,active').eq('organization_id',membership.organization_id).eq('active',true).order('name').limit(1000);
 if(error){message('تعذر تحميل الأصناف. تحقق من الجداول وسياسات RLS.');return;}
 items=data||[];errorMsg='';render();
}
function showItemForm(){
 if(!canEdit())return;
 $('#itemform').innerHTML=`<form id="newitem" class="panel"><h4>إضافة صنف</h4><div class="grid"><div class="field"><label>الكود</label><input name="sku" required></div><div class="field"><label>اسم الصنف</label><input name="name" required></div><div class="field"><label>الوحدة</label><input name="base_unit" value="حبة" required></div><div class="field"><label>الرصيد الدفتري</label><input name="book_qty" type="number" min="0" step="any" value="0" required></div><div class="field"><label>حد الطلب</label><input name="min_qty" type="number" min="0" step="any" value="0"></div><div class="field"><label>التكلفة</label><input name="cost" type="number" min="0" step="any" value="0"></div><div class="field"><label>سعر البيع</label><input name="sale_price" type="number" min="0" step="any" value="0"></div></div><div class="row"><button class="btn">حفظ في قاعدة البيانات</button><button type="button" id="cancel" class="alt">إلغاء</button></div></form>`;
 $('#cancel').onclick=()=>$('#itemform').replaceChildren();
 $('#newitem').onsubmit=async e=>{e.preventDefault();const f=new FormData(e.target);const row={organization_id:membership.organization_id,sku:String(f.get('sku')).trim(),name:String(f.get('name')).trim(),base_unit:String(f.get('base_unit')).trim(),book_qty:Number(f.get('book_qty')||0),min_qty:Number(f.get('min_qty')||0),cost:Number(f.get('cost')||0),sale_price:Number(f.get('sale_price')||0)};const {error}=await client.from('items').insert(row);if(error){message(error.code==='23505'?'هذا الكود مسجل من قبل.':'تعذر حفظ الصنف. راجع صلاحيات قاعدة البيانات والحقول.');return;}okMsg='تم حفظ الصنف في قاعدة البيانات المشتركة.';errorMsg='';await loadItems();};
}
async function init(){
 if(!client){render();return;}
 const {data}=await client.auth.getSession();session=data.session;
 client.auth.onAuthStateChange((_event,s)=>{session=s;setTimeout(async()=>{if(session)await resolveMembership();else{membership=null;items=[];render();}},0);});
 if(session)await resolveMembership();else render();
}
init();
